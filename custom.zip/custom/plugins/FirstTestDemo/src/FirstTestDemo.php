<?php declare(strict_types=1);

namespace FirstTestDemo;

use Shopware\Core\Framework\Plugin;

class FirstTestDemo extends Plugin
{
}